// Factory.java
//
// Factory class that creates the bank and each bank customer
// Usage:  java Factory 10 5 7

import java.io.*;
import java.util.*;
import java.util.Scanner;


public class Factory {
    public static void main(String[] args) {
        /*
            Input files with processes initial allocation/max values
            are passed as arguments to program (args[0]). Initial
            available resources are passed as args[1] to args[n].
                    - args[0] = exampleFile.txt
                    - args[1 to n] = Available resources

            Using Intellij 2020.0
            Run->Edit Configurations->Program Arguments
            Working Directory must be set to project directory to
            access input files.

              Program Arguments Example usage: "infileLarge.txt 10 7 9 8"

            Included Files:
                    - infileSmall.txt -> For Resources, must have 1 value passed
                    - infileMedium.txt -> For Resources, must have 3 values passed
                    - infileLarge.txt -> For Resources, must have 4 values passed
            If resources passed in arguments do not match file, error will be thrown.
            with correct amount of resources to pass.
         */
        String filename = args[0];
        System.out.print("Opening and processing file: " + filename);

        // READ user provided resources from passed arguments
        // ERROR if resources passed in arguments does not match file
        int nResources = args.length - 1;
        // Check the correct number of arguments were passed.
        try {
            Scanner sc = new Scanner((new FileInputStream(filename)));
            int width = sc.nextLine().replace(" ", "").length();
            int split = (width / 2);
            if (split != nResources) {
                throw new Exception(Integer.toString(split), null);
            }
        } catch (Exception e) {
            String msg = e.getMessage();
            System.out.println("\n\nIncorrect Parameter Count\n" + filename + " requires " + msg + " argument(s) to be passed.");
            System.exit(1);
        }

        int[] resources = new int[nResources];
        for (int i = 0, j = 1; i < nResources; i++) {
            resources[i] = Integer.parseInt(args[j].trim());
            j++;
        }
        System.out.print(", Initial resources provided: " + Arrays.toString(resources) + "\n");
        // Determine number of threads in infile prior to bank initialization.
        int processes = 0;
        try {
            Scanner scan = new Scanner(new FileInputStream(filename));
            String throwaway = "";
            while (scan.hasNextLine()) {
                throwaway = scan.nextLine();
                processes++;
            }
        } catch (FileNotFoundException notFound) { throw new Error("Unable to find file"); }

        bankers theBank = new BankImpl(resources, processes);   // Create new BankImpl using resources(passed arguments)
        int[] maxDemand = new int[nResources];                  // The Max Demand for each process
        int[] allocated = new int[nResources];                  // Initial Allocated resources for process
        Thread[] workers = new Thread[processes];          // the customers

        // read in values and initialize the matrices
        // READ INFILE
        try {
            // Declare variables for reading the input file
            Scanner scan = new Scanner(new FileInputStream(filename));
            int fileIndex = 0, arrayIndex = 0, threadNum = 0;

            /*
                Calculate line width - how many resources for
                Allocation and how many for Max.

                ex.  Alloc     Max
                     0 1 0    7 5 4

                     width - returns 6
                     split - returns the array index where alloc ends (2)
                     width -= 1 -> aligns width to array index convention
                                   'starting from 0'
            */
            // Scanner sc to determine amount of resources for each thread in infile
            Scanner sc = new Scanner((new FileInputStream(filename)));
            int width = sc.nextLine().replace(" ", "").length();
            int split = (width / 2) - 1;
            width -= 1;

            // Read file and ...
            while (scan.hasNextLine()) {
                int x = scan.nextInt();                                 // Grab integer literal
                if (fileIndex <= split) {
                    allocated[arrayIndex] = x;
                }
                else {
                    maxDemand[arrayIndex] = x;
                }
                fileIndex++;
                arrayIndex++;
                if (arrayIndex > split) {
                    arrayIndex = 0;
                }
                if (fileIndex > width) {
                    theBank.addCustomer(threadNum, allocated, maxDemand);
                    fileIndex = 0;
                    new customer(threadNum, maxDemand, theBank);
                    workers[threadNum] = new Thread();
                    ++threadNum;
                }
            }
            scan.close(); // CLOSE INFILE
        } catch (FileNotFoundException notFound) { throw new Error("Unable to find file"); }
        // END INFILE READ

        // start the customers
        System.out.println("FACTORY: created threads");
        for (int i = 0; i < processes; i++) { workers[i].start(); }
        System.out.println("FACTORY: started threads");

        // GET STARTING STATE
        theBank.getState();
        // Start Simulation
        theBank.runSimulation(workers.length, nResources);

    }
}

