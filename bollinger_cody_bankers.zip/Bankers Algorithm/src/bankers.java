//--------------------------------------------------------------------------
// bankers.java
//
public interface bankers {

    void addCustomer(int threadNum, int[] maxDemand, int[] allocated);
    // add customer to Bank

    void getState();
    // outputs available, allocation, max, and need matrices

    void runSimulation(int processCount, int numResources);
    // processCount - count of all customers in input file for use in random requests
    // numResources - total number of resources passed as arguments
    // ----Generates random requests to random processes 

    boolean requestResources(int threadNum, int[] request);
    // Request Resources
    void releaseResources(int threadNum, int[] release);
    // Release Resources
}