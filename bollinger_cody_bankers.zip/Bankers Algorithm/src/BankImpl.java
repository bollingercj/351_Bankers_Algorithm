// BankImpl.java
//
// implementation of the Bank
//
import java.io.*;
import java.util.*;
public class BankImpl implements bankers {
    private int n;          // the number of threads in the system
    private int m;          // the number of resources

    private int[] available;    // the amount available of each resource
    private int[][] maximum;    // the maximum demand of each thread
    private int[][] allocation; // the amount currently allocated to each thread
    private int[][] need;       // the remaining needs of each thread

    private void showAllMatrices(int[][] alloc, int[][] max, int[][] need, int numProcesses, int numResources) {
        // First calculate the need matrix
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                need[i][j] = max[i][j] - alloc[i][j];
            }
        }
        // using number of resources get a rough spacing to format output title centered above matrix
        int blankSpace1 = (numResources * 2) - 2;
        int blankSpace2 = (numResources * 2) + 1;
        String space1 = String.format("%1$" + blankSpace1 + "s", "");
        String space2 = String.format("%1$" + blankSpace2 + "s","");
        System.out.println(" ALLOCATION" + space1 + "MAXIMUM" + space2 + "NEED");

        int rowCount = 0;          // start from row 0 (process 0) all the way to n processes
        while (rowCount < numProcesses) {
            // Print Allocation
            System.out.print("[ ");
            for (int i = 0; i < numResources; i++) {
                System.out.print(alloc[rowCount][i] + " ");
            }
            // Print Max
            System.out.print("]     [ ");
            for (int i = 0; i < numResources; i++) {
                System.out.print(max[rowCount][i] + " ");
            }
            // Print Need
            System.out.print("]     [ ");
            for (int i = 0; i < numResources; i++) {
                System.out.print(need[rowCount][i] + " ");
            }
            System.out.print("]\n");
            rowCount ++;
        }
    }

    private void showMatrix(int[][] matrix, String title, int numProcesses, int numResources) {
        // Print SINGLE matrix
        System.out.println(title);
        int rowCount = 0;
        while (rowCount < numProcesses) {
            System.out.print("[ ");
            for (int i = 0; i < numResources; i++) {
                System.out.print(matrix[rowCount][i] + " ");
            }
            System.out.print("]\n");
            rowCount++;
        }
    }

    // Prints current available
    public void showVector(int[] availVector) {
        System.out.print("Available: [ ");
        for (int i = 0; i < availVector.length; i++) {
            System.out.print(availVector[i] + " ");
        }
        System.out.print("]\n\n");
    }

    public BankImpl(int[] resources, int processes) {
        // Create new bank (with resources)
        this.m = resources.length;
        this.n = processes;
        allocation = new int[n][m];
        maximum = new int[n][m];
        need = new int[n][m];
        available = new int[m];
        for (int i = 0; i < resources.length; i++) {
            this.available[i] = resources[i];
        }
    }

    // invoked by a thread when it enters the system;  also records max demand
    public void addCustomer(int threadNum, int[] allocated, int[] maxDemand) {
        int size = allocated.length;
        for (int i = 0; i < size; i++) {
            this.allocation[threadNum][i] = allocated[i];
        }
        for (int i = 0; i < size; i++) {
            this.maximum[threadNum][i] = maxDemand[i];
        }
        System.out.println("Adding new customer: " + threadNum);
    }

    // output state for every thread
    public void getState() { this.showAllMatrices(this.allocation, this.maximum, this.need, this.n, this.m); }

    private boolean isSafeState(int threadNum, int[] request) {
        /*
            Safety Algorithm - Page 335 (Silbershatz 10th ed)
            1. Work[] = Available[]
               Finish[i] = false
            2. Find an index that has (Finish[i] == false && Need <= Work)
               If found -> Step 3, If not found, move to step 4.
            3. Work = Work + Allocation
               Finish[i] = true
               Go back to step 2.
            4. If (Finish[i] == true) FOR ENTIRE ARRAY, In SAFE STATE.
         */
        // Immediately rule out if request cannot be granted.
        //    - requested is greater then the processes Need or requested is greater
        //      then the available resources.
        for (int i = 0; i < m; i++) {
            if (request[i] > need[threadNum][i] || request[i] > available[i]) {
                return false;
            }
        }
        // Step 1 (Initialize Work[] and Finish[])
        int[] Work = new int[m];
        if (m >= 0) System.arraycopy(available, 0, Work, 0, m);
        boolean[] Finish = new boolean[n];
        for (int i = 0; i < n; i++) { Finish[i] = false; }

        // Step 2 ( Find index that has (Finish[i] == false && Need <= Work)
        int rowCount = 0;
        while (rowCount < n) {
            for (int i = 0; i < n; i++) {
                if (!Finish[i]) {
                    boolean indexFound = true;
                    for (int j = 0; j < Work.length; j++) {
                        if (need[i][j] > Work[j]) { indexFound = false; }
                    }
                    // Step 3 (Work += Allocation), Finish[j] = true;
                    if (indexFound) {
                        Finish[i] = true;
                        for (int k = 0; k < m; k++) { Work[k] += allocation[i][k]; }
                    }
                }
            }
            rowCount++;
        }

        // Step 4 Check entire Finish[] for ALL true to determine safe state.
        boolean isSafe = true;
        for (boolean finish : Finish) {
            if (!finish) {
                isSafe = false;
                break;
            }
        }
        return isSafe;
    }

    // make request for resources. will block until request is satisfied safely
    public synchronized boolean requestResources(int threadNum, int[] request) {
        // If it is not safe -> return false(DENY REQUEST)
        if (!isSafeState(threadNum, request)) { return false; }

        // IS safe -> give requested resources
        for (int i = 0; i < m; i++) {
            available[i] -= request[i];
            allocation[threadNum][i] += request[i];
            // Calculate NEW need matrix after requested resources are given.
            need[threadNum][i] = maximum[threadNum][i] - allocation[threadNum][i];
        }
        System.out.println("Process: " + threadNum + " request was APPROVED!" + " Now Available: " + Arrays.toString(available));
        this.checkNeed(threadNum); // Check if process has all its needed resources. Also checks for final completion.
        return true;
    }

    public synchronized void releaseResources(int threadNum, int[] release) {
        System.out.println("Process: " + threadNum + " has all its resources! RELEASING " + Arrays.toString(maximum[threadNum]) + " and SHUTTING DOWN");
        // Release(add resources back to available[] matrix)
        for (int i = 0; i < m; i++) {
            available[i] += release[i];
            allocation[threadNum][i] -= release[i];
            need[threadNum][i] = maximum[threadNum][i] + allocation[threadNum][i];
        }
        // Show Available resources after release
        System.out.print("After Release New ");
        showVector(this.available);
        // Set finished processes alloc/max/need matrices to 0
        for (int i = 0; i < m; i++) {
            allocation[threadNum][i] = 0;
            maximum[threadNum][i] = 0;
            need[threadNum][i] = 0;
        }
    }

    public void runSimulation(int processCount, int numResources) {
        int[] request = new int[numResources];   // Random request array
        while (true) {
            Random rand = new Random();
            // Random process that will request
            int processNum = rand.nextInt(processCount);

            // FILL request array(randomly)
            System.out.print("\nProcess: " + processNum + " Requesting: ");
            for (int i = 0; i < numResources; i++) { request[i] = rand.nextInt(4); }
            System.out.println(Arrays.toString(request) + ", Available: " + Arrays.toString(available));

            // resourcesGranted will be true if isSafe, false otherwise -> request will be denied
            boolean resourcesGranted = this.requestResources(processNum, request);
            if (resourcesGranted) { this.getState(); }
            else { System.out.println("Process: " + processNum + " -> Denied request for resources"); }

            // Sleep so output can be read during runtime
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {}
        }
    }

    public void checkNeed(int threadNum) {
        // CHECK if process has reached MAX demand(completed) and can release resources back.
        int[] releasable = new int[m];      // potential resources that can be released.
        boolean checkNeed = true;
        for (int i = 0; i < m; i++) {
            if (need[threadNum][i] != 0) {
                // CHECK if the processes need matrix is all 0's ->[0, 0, 0....]
                checkNeed = false;
            }
        }
        if (checkNeed) {
            // Process has all its resources -> call(releaseResources) to give resources back to available[].
            int [] getResource = new int[m];
            for (int i = 0; i < m; i++) { getResource[i] = maximum[threadNum][i]; }
            System.arraycopy(getResource, 0, releasable, 0, m);
            releaseResources(threadNum, releasable);
        }
        // Will check for completion (ALl threads receiving their needed resources) and exit(0) the program.
        boolean completion = true;
        int rowCount = 0;
        while (rowCount < n) {
            for (int i = 0; i < m; i++) {
                if (need[rowCount][i] != 0) {
                    completion = false;
                    break;
                }
            }
            rowCount++;
        }
        if (completion) {
            System.out.println("All threads have finished successfully -> Shutting down");
            System.exit(0);
        }
    }
}
